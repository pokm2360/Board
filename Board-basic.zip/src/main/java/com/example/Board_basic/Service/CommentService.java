package com.example.Board_basic.Service;

import com.example.Board_basic.Dto.CommentDto;
import com.example.Board_basic.Entity.Comment;
import com.example.Board_basic.Entity.Post;
import com.example.Board_basic.Repository.CommentRepository;
import com.example.Board_basic.Repository.PostRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CommentService {

    private final CommentRepository commentRepository;
    private final PostRepository postRepository;

    /** 댓글 평탄 리스트 (작성순) */
    @Transactional(readOnly = true)
    public List<CommentDto> listByPostFlat(Long postId) {
        return commentRepository.findByPostIdOrderByCreatedDateAsc(postId)
                .stream()
                .map(CommentDto::fromEntity)
                .toList();
    }

    /** 원댓글 작성 */
    @Transactional
    public Long add(Long postId, String content, String nickname) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new IllegalArgumentException("게시글이 존재하지 않습니다."));

        Comment c = commentRepository.save(
                Comment.builder()
                        .post(post)
                        .parent(null)
                        .depth(0)
                        .content(content)
                        .writer(nickname)
                        .createdDate(LocalDateTime.now())
                        .build()
        );
        return c.getId();
    }

    /** 대댓글 작성 (부모가 같은 게시글인지 검증 + depth 설정) */
    @Transactional
    public Long reply(Long postId, Long parentId, String content, String nickname) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new IllegalArgumentException("게시글이 존재하지 않습니다."));

        Comment parent = commentRepository.findById(parentId)
                .orElseThrow(() -> new IllegalArgumentException("부모 댓글이 존재하지 않습니다."));

        // 부모가 같은 게시글에 속하는지 검증
        if (!parent.getPost().getId().equals(postId)) {
            throw new IllegalArgumentException("부모 댓글이 해당 게시글의 댓글이 아닙니다.");
        }

        Comment c = commentRepository.save(
                Comment.builder()
                        .post(post)
                        .parent(parent)
                        .depth(parent.getDepth() + 1)
                        .content(content)
                        .writer(nickname)
                        .createdDate(LocalDateTime.now())
                        .build()
        );
        return c.getId();
    }

    /** 댓글 삭제 (작성자 또는 관리자) */
    @Transactional
    public void delete(Long commentId, String nickname, boolean isAdmin) {
        Comment c = commentRepository.findById(commentId)
                .orElseThrow(() -> new IllegalArgumentException("댓글이 존재하지 않습니다."));

        if (!isAdmin && !c.getWriter().equals(nickname)) {
            throw new SecurityException("삭제 권한이 없습니다.");
        }
        commentRepository.delete(c);
    }
}
