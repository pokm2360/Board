package com.example.Board_basic.Controller;

import com.example.Board_basic.Dto.PostDto;
import com.example.Board_basic.Entity.Post;
import com.example.Board_basic.Service.CommentService;
import com.example.Board_basic.Service.PostService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;
    private final CommentService commentService;

    /** 목록 (페이징 + 검색) */
    @GetMapping({"/", "/list"})
    public String list(@RequestParam(defaultValue = "0") int page,
                       @RequestParam(required = false) String keyword,
                       @RequestParam(defaultValue = "all") String scope,
                       Model model) {

        if (page < 0) page = 0;

        Pageable pageable = PageRequest.of(page, 10, Sort.by("id").descending());
        Page<Post> postPage = (keyword != null && !keyword.isBlank())
                ? postService.search(keyword.trim(), scope, pageable)
                : postService.findAll(pageable);

        model.addAttribute("posts", postPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", postPage.getTotalPages());
        model.addAttribute("keyword", keyword);
        model.addAttribute("scope", scope);

        return "list.html";
    }

    /** 작성 폼 */
    @GetMapping("/write")
    public String writeForm() {
        return "write.html";
    }

    /** 작성 처리 */
    @PostMapping("/writepost")
    public String write(@Valid @ModelAttribute PostDto dto,
                        BindingResult result,
                        @AuthenticationPrincipal(expression = "user.nickname") String nickname) {
        if (result.hasErrors()) {
            return "write.html";
        }
        if (nickname == null || nickname.isBlank()) {
            return "redirect:/loginform"; // 로그인 페이지로
        }

        dto.setWriter(nickname); // 작성자 = 닉네임
        postService.save(dto);
        return "redirect:/";
    }

    /** 상세 조회 (+ 유니크 조회수, 좋아요 상태/개수, 댓글) */
    @GetMapping("/posts/read/{id}")
    public String read(@PathVariable Long id,
                       HttpServletRequest request,
                       Authentication auth,
                       Model model) {

        String username = (auth != null) ? auth.getName() : null;

        // 유니크 조회수 증가 (로그인=username / 비로그인=ip 기준, 1일 1회)
        String ip = request.getRemoteAddr();
        postService.increaseUniqueView(id, username, ip);

        PostDto post = postService.findById(id);
        model.addAttribute("posts", post);

        // 댓글 목록(평탄화)
        model.addAttribute("comments", commentService.listByPostFlat(id));

        // 좋아요 상태/개수
        model.addAttribute("likeCount", postService.likeCount(id));
        model.addAttribute("liked", username != null && postService.hasLiked(id, username));

        return "read.html";
    }

    /** 좋아요 토글 (한 번 더 누르면 취소) */
    @PostMapping("/posts/{id}/like")
    public ResponseEntity<?> toggleLike(@PathVariable Long id,
                                        Authentication auth,
                                        @RequestHeader(value = "X-Requested-With", required = false) String requestedWith,
                                        @RequestHeader(value = "Accept", required = false) String accept) {
        if (auth == null) {
            // AJAX면 401, 일반 폼이면 로그인으로 redirect
            if ("XMLHttpRequest".equalsIgnoreCase(requestedWith) || (accept != null && accept.contains("application/json"))) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }
            return ResponseEntity.status(HttpStatus.FOUND)
                    .header(HttpHeaders.LOCATION, "/loginform")
                    .build();
        }

        boolean liked = postService.toggleLike(id, auth.getName());
        long count = postService.likeCount(id);

        // AJAX면 JSON 반환
        if ("XMLHttpRequest".equalsIgnoreCase(requestedWith) || (accept != null && accept.contains("application/json"))) {
            return ResponseEntity.ok(Map.of("liked", liked, "count", count));
        }

        // 폴백: 기존처럼 redirect
        return ResponseEntity.status(HttpStatus.FOUND)
                .header(HttpHeaders.LOCATION, "/posts/read/" + id)
                .build();
    }

    /** 대댓글 등록 */
    @PostMapping("/posts/{postId}/comments/{parentId}/reply")
    public String reply(@PathVariable Long postId,
                        @PathVariable Long parentId,
                        @RequestParam String content,
                        @AuthenticationPrincipal(expression = "user.nickname") String nickname) {
        if (nickname == null || nickname.isBlank()) return "redirect:/loginform";
        commentService.reply(postId, parentId, content, nickname);
        return "redirect:/posts/read/" + postId;
    }

    /** 삭제 */
    @PostMapping("/posts/delete/{id}")
    public String delete(@PathVariable Long id) {
        postService.delete(id);
        return "redirect:/list";
    }

    /** 검색 결과 페이지 (리스트와 동일한 페이지네이션 UI) */
    @GetMapping("/posts/search")
    public String search(@RequestParam String keyword,
                         @RequestParam(defaultValue = "all") String scope,
                         @RequestParam(defaultValue = "0") int page,
                         Model model) {

        if (keyword == null || keyword.isBlank()) {
            return "redirect:/list"; // 가드 (프론트에서도 막고 있지만 직접 접근 대비)
        }
        if (page < 0) page = 0;

        Pageable pageable = PageRequest.of(page, 10, Sort.by("id").descending());
        Page<Post> result = postService.search(keyword.trim(), scope, pageable);

        // 현재 page가 총 페이지 초과하면 마지막 페이지로 보정
        int last = Math.max(0, result.getTotalPages() - 1);
        if (page > last && result.getTotalPages() > 0) {
            pageable = PageRequest.of(last, 10, Sort.by("id").descending());
            result = postService.search(keyword.trim(), scope, pageable);
            page = last;
        }

        model.addAttribute("keyword", keyword);
        model.addAttribute("scope", scope);
        model.addAttribute("searchList", result.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", result.getTotalPages());

        return "search.html";
    }
}




