package com.example.Board_basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
